-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: laravel_erp
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_credentials`
--

DROP TABLE IF EXISTS `access_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_credentials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `platform` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `last_accessed_at` timestamp NULL DEFAULT NULL,
  `access_count` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_credentials_client_id_foreign` (`client_id`),
  KEY `access_credentials_organization_id_client_id_index` (`organization_id`,`client_id`),
  KEY `access_credentials_platform_index` (`platform`),
  KEY `access_credentials_last_accessed_at_index` (`last_accessed_at`),
  CONSTRAINT `access_credentials_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `access_credentials_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_credentials`
--

LOCK TABLES `access_credentials` WRITE;
/*!40000 ALTER TABLE `access_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annexes`
--

DROP TABLE IF EXISTS `annexes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annexes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `contract_id` bigint(20) unsigned NOT NULL,
  `annex_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` enum('annex','amendment') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'annex',
  `version` int(11) NOT NULL DEFAULT '1',
  `signed_date` date DEFAULT NULL,
  `pdf_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `annexes_annex_number_unique` (`annex_number`),
  KEY `annexes_contract_id_foreign` (`contract_id`),
  KEY `annexes_organization_id_contract_id_index` (`organization_id`,`contract_id`),
  CONSTRAINT `annexes_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `annexes_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annexes`
--

LOCK TABLES `annexes` WRITE;
/*!40000 ALTER TABLE `annexes` DISABLE KEYS */;
/*!40000 ALTER TABLE `annexes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_settings`
--

DROP TABLE IF EXISTS `application_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `application_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_settings`
--

LOCK TABLES `application_settings` WRITE;
/*!40000 ALTER TABLE `application_settings` DISABLE KEYS */;
INSERT INTO `application_settings` VALUES (1,'app_name','Simplead ERP','string','2025-11-11 06:47:41','2025-11-11 06:48:46'),(2,'app_logo','app-settings/gN59pWpXNbGREi8Xxr5hUTeb1pu0IKSOed0DdSKG.jpg','file','2025-11-11 06:47:41','2025-11-11 07:32:27'),(3,'app_favicon','app-settings/CTWQ9Sgh7tkxusMLKxP1XHiQnmV1T8SpBaRNSHtC.png','file','2025-11-11 06:47:41','2025-11-11 06:58:09'),(4,'theme_mode','light','string','2025-11-11 06:47:41','2025-11-11 06:47:41'),(5,'primary_color','#957aff','string','2025-11-11 06:47:41','2025-11-11 06:52:20'),(6,'language','ro','string','2025-11-11 06:47:41','2025-11-11 06:47:41'),(7,'timezone','Europe/Bucharest','string','2025-11-11 06:47:41','2025-11-11 06:47:41'),(8,'date_format','d/m/Y','string','2025-11-11 06:47:41','2025-11-11 06:47:41');
/*!40000 ALTER TABLE `application_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  KEY `audit_logs_organization_id_user_id_model_type_created_at_index` (`organization_id`,`user_id`,`model_type`,`created_at`),
  CONSTRAINT `audit_logs_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('laravel-cache-app_setting_app_favicon','s:57:\"app-settings/CTWQ9Sgh7tkxusMLKxP1XHiQnmV1T8SpBaRNSHtC.png\";',1762868007),('laravel-cache-app_setting_app_logo','s:57:\"app-settings/gN59pWpXNbGREi8Xxr5hUTeb1pu0IKSOed0DdSKG.jpg\";',1762868007),('laravel-cache-app_setting_app_name','s:12:\"Simplead ERP\";',1762868007),('laravel-cache-app_setting_date_format','s:5:\"d/m/Y\";',1762868007),('laravel-cache-app_setting_language','s:2:\"ro\";',1762868007),('laravel-cache-app_setting_primary_color','s:7:\"#957aff\";',1762868007),('laravel-cache-app_setting_theme_mode','s:5:\"light\";',1762868007),('laravel-cache-app_setting_timezone','s:16:\"Europe/Bucharest\";',1762868007);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_settings`
--

DROP TABLE IF EXISTS `client_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#3B82F6',
  `color_background` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#EFF6FF',
  `color_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#1E40AF',
  `order_index` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_settings_user_id_is_active_index` (`user_id`,`is_active`),
  KEY `client_settings_order_index_index` (`order_index`),
  CONSTRAINT `client_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_settings`
--

LOCK TABLES `client_settings` WRITE;
/*!40000 ALTER TABLE `client_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `status_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `vat_payer` tinyint(1) NOT NULL DEFAULT '0',
  `total_incomes` decimal(15,2) NOT NULL DEFAULT '0.00',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_slug_unique` (`slug`),
  UNIQUE KEY `clients_tax_id_user_id_unique` (`tax_id`,`user_id`),
  KEY `clients_status_id_foreign` (`status_id`),
  KEY `clients_user_id_status_id_index` (`user_id`,`status_id`),
  KEY `clients_order_index_index` (`order_index`),
  CONSTRAINT `clients_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `client_settings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `clients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,1,NULL,'Mihaela Tatu','Mihaela Tatu','mihaela-tatu',NULL,NULL,NULL,'contact@mihaelatatu.ro',NULL,NULL,0,0.00,NULL,0,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(2,1,NULL,'Test','Simplead S.R.L.','test','41501661','J171/488/2019',NULL,NULL,NULL,'Str. Podul Înalt, 5, Bl:p5, Sc:4, Et:4, Ap:76, -, Galați',0,0.00,'zdghfghfh',1,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(3,1,NULL,'Halep Constanta','Yucatan Bay S.R.L.','halep-constanta','RO45596575','J2022000398134',NULL,'simonahalephotel@gmail.com',NULL,'Bld. Tomis, Nr.261, Bl.T3, Sc.B, Et.Parter, Ap.19 Constanta',1,0.00,NULL,2,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(4,1,NULL,'APAIR','APAIR','apair','-',NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,3,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(5,1,NULL,'Priority Clinic','Priority Coaching S.R.L.','priority-clinic','RO35938905','J40/5294/2016',NULL,NULL,'0723553035','Str. Nerva Traian, 17-19, Bl:m70, Sc:1, Et:1, Ap:2, -, București, Sect 3',1,0.00,NULL,4,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(6,1,NULL,'Premium Stone','Universal Stone S.R.L.','premium-stone','RO37071523','J40/1853/2017',NULL,NULL,NULL,'Calea Giulesti, Nr. 111, Bl. 5, Sc. A, Et. 1, Ap. 6, Camera 1, Sect. 6',1,0.00,NULL,5,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(7,1,NULL,'Roll Shape','Solis Investment Branco S.R.L.','roll-shape','RO36741803','J40/15026/2016',NULL,NULL,NULL,'Str. Anastasie Panu, Nr.50, Demisol, Camera F Sector 3',1,0.00,NULL,6,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(8,1,NULL,'Florin Pasat','Florimage S.R.L.','florin-pasat','RO18295630','J38/41/2006','Florin Pasat','florinpasat@yahoo.com',NULL,'Str. Doctor Hacman, Nr.16, Camera 1, Bl.89, Sc.C, Et.4, Ap.9',1,0.00,NULL,7,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(9,1,NULL,'Liceul ICHB','Liceul Teoretic International De Informatica Bucuresti','liceul-ichb','35618226',NULL,NULL,NULL,'0213276570','Balta Albina, 9, -, Bucuresti, Sect 3',1,0.00,NULL,8,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(10,1,NULL,'Stefan Chelmu','Blitzstudio Sic S.R.L.','stefan-chelmu','35783983','J201/600043/4172',NULL,NULL,NULL,'Str Brăilei, 188, Bl:a4, Sc:1, Et:5, Ap:21, -, Galați',0,0.00,NULL,9,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(11,1,NULL,'Proventus Anmar','Proventus Anmar S.R.L.','proventus-anmar','RO24500925','J200/801617/8401',NULL,NULL,NULL,'Str Istriei, 22, Bl:3d, Sc:2, Et:2, Ap:24, -, București, Sect 3',1,0.00,NULL,10,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(12,1,NULL,'Georgiana Ungureanu','Priority Art Education S.R.L.','georgiana-ungureanu','44809640','J40/14826/2021','Georgiana Ungureanu','georgi.oprea@yahoo.com',NULL,'Str. Petre Ispirescu, Nr.19, Bl.M213, Sc.A, Et.7, Ap.30',0,0.00,NULL,11,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(13,1,NULL,'International School of Oradea','ASOCIATIA I.S.O.','international-school-of-oradea','RO38426780','-','Anca Popa','admissions@isor.ro','0770 903 819','Str. Armatei Romane, Nr.1f Oradea',1,0.00,NULL,12,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(14,1,NULL,'Speaker Marketing','Speaker Marketing S.R.L.','speaker-marketing','RO37784365','J4096152017',NULL,NULL,NULL,'Șos. Nicolae Titulescu, 1, Bl:a7, Et:6, Ap:77, -, București, Sect 1',1,0.00,NULL,13,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(15,1,NULL,'Fastrackids','Beekids S.R.L.','fastrackids','26785187','J091662010',NULL,NULL,NULL,'Str. Mărului, 123, -, Brăila',0,0.00,NULL,14,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(16,1,NULL,'Simona Halep','New Concept Imob S.R.L.','simona-halep','RO33146569','J201/400096/1131',NULL,NULL,NULL,'Bld Tomis, 261, Bl:t3, Sc:b, Et:p, Ap:19, -, Constanța',1,0.00,NULL,15,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(17,1,NULL,'Matematica Interactiva','Smartmath Club S.R.L.','matematica-interactiva','43805144','J202/100343/7400',NULL,'contact@matematica-interactiva.ro','0744440141','Str Rușchița, 37, -, București, Sect 2',0,0.00,NULL,16,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(18,1,NULL,'Paul Ardeleanu','Marketing Deck Global S.R.L.','paul-ardeleanu','42693727','J407/083/2020',NULL,NULL,NULL,'Șos. Nicolae Titulescu, 1, Bl:a7, Et:6, Ap:77, Camera 1, București, Sect 1',0,0.00,NULL,17,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL),(19,1,NULL,'M1 Beauty',NULL,'m1-beauty','DE283685131',NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,18,'2025-11-11 12:35:58','2025-11-11 12:35:58',NULL);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `offer_id` bigint(20) unsigned DEFAULT NULL,
  `contract_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('draft','active','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `version` int(11) NOT NULL DEFAULT '1',
  `signed_date` date DEFAULT NULL,
  `pdf_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contracts_contract_number_unique` (`contract_number`),
  KEY `contracts_client_id_foreign` (`client_id`),
  KEY `contracts_organization_id_client_id_status_index` (`organization_id`,`client_id`,`status`),
  CONSTRAINT `contracts_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contracts_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domains`
--

DROP TABLE IF EXISTS `domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned DEFAULT NULL,
  `domain_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registrar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Expiring','Expired','Suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `registration_date` date DEFAULT NULL,
  `expiry_date` date NOT NULL,
  `annual_cost` decimal(10,2) DEFAULT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domains_domain_name_unique` (`domain_name`),
  KEY `domains_client_id_foreign` (`client_id`),
  KEY `domains_organization_id_expiry_date_index` (`organization_id`,`expiry_date`),
  KEY `domains_organization_id_client_id_index` (`organization_id`,`client_id`),
  KEY `domains_domain_name_index` (`domain_name`),
  CONSTRAINT `domains_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `domains_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domains`
--

LOCK TABLES `domains` WRITE;
/*!40000 ALTER TABLE `domains` DISABLE KEYS */;
INSERT INTO `domains` VALUES (1,1,NULL,'test.com',NULL,'Active','2025-11-07','2025-11-27',NULL,1,NULL,'2025-11-11 05:53:35','2025-11-11 05:53:35',NULL);
/*!40000 ALTER TABLE `domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `expense_date` date NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receipt_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_recorded_by_foreign` (`recorded_by`),
  KEY `expenses_organization_id_expense_date_category_index` (`organization_id`,`expense_date`,`category`),
  CONSTRAINT `expenses_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `expenses_recorded_by_foreign` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `fileable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `folder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `uploaded_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_fileable_type_fileable_id_index` (`fileable_type`,`fileable_id`),
  KEY `files_uploaded_by_foreign` (`uploaded_by`),
  KEY `files_organization_id_fileable_type_fileable_id_index` (`organization_id`,`fileable_type`,`fileable_id`),
  CONSTRAINT `files_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `files_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_expenses`
--

DROP TABLE IF EXISTS `financial_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `document_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RON',
  `occurred_at` date NOT NULL,
  `category_option_id` bigint(20) unsigned DEFAULT NULL,
  `year` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `financial_expenses_user_id_foreign` (`user_id`),
  KEY `financial_expenses_organization_id_user_id_index` (`organization_id`,`user_id`),
  KEY `financial_expenses_year_month_index` (`year`,`month`),
  KEY `financial_expenses_currency_index` (`currency`),
  KEY `financial_expenses_category_option_id_index` (`category_option_id`),
  CONSTRAINT `financial_expenses_category_option_id_foreign` FOREIGN KEY (`category_option_id`) REFERENCES `financial_settings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_expenses_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_expenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_expenses`
--

LOCK TABLES `financial_expenses` WRITE;
/*!40000 ALTER TABLE `financial_expenses` DISABLE KEYS */;
INSERT INTO `financial_expenses` VALUES (1,1,1,'Google Ads Campaign',1500.00,'RON','2025-08-11',6,2025,8,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(2,1,1,'Adobe Creative Cloud',60.00,'EUR','2025-08-15',1,2025,8,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(3,1,1,'AWS Hosting',450.00,'EUR','2025-09-14',2,2025,9,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(4,1,1,'Office Supplies',350.00,'RON','2025-09-23',1,2025,9,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(5,1,1,'Accountant Services',800.00,'RON','2025-10-28',7,2025,10,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(6,1,1,'GitHub Pro',45.00,'EUR','2025-10-03',8,2025,10,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 19:17:34','2025-11-10 19:17:34'),(7,1,1,'Employee Salary',5000.00,'RON','2025-11-05',8,2025,11,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 19:10:05','2025-11-10 19:10:05'),(8,1,1,'Internet & Phone',120.00,'RON','2025-11-01',1,2025,11,'Sample expense entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL);
/*!40000 ALTER TABLE `financial_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_files`
--

DROP TABLE IF EXISTS `financial_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `entity_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` bigint(20) unsigned NOT NULL,
  `an` int(11) DEFAULT NULL,
  `luna` int(11) DEFAULT NULL,
  `tip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `financial_files_user_id_foreign` (`user_id`),
  KEY `financial_files_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  KEY `financial_files_organization_id_user_id_index` (`organization_id`,`user_id`),
  KEY `financial_files_an_luna_index` (`an`,`luna`),
  KEY `financial_files_tip_index` (`tip`),
  CONSTRAINT `financial_files_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_files`
--

LOCK TABLES `financial_files` WRITE;
/*!40000 ALTER TABLE `financial_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `financial_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_revenues`
--

DROP TABLE IF EXISTS `financial_revenues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_revenues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `document_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RON',
  `occurred_at` date NOT NULL,
  `client_id` bigint(20) unsigned DEFAULT NULL,
  `year` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `financial_revenues_user_id_foreign` (`user_id`),
  KEY `financial_revenues_client_id_foreign` (`client_id`),
  KEY `financial_revenues_organization_id_user_id_index` (`organization_id`,`user_id`),
  KEY `financial_revenues_year_month_index` (`year`,`month`),
  KEY `financial_revenues_currency_index` (`currency`),
  CONSTRAINT `financial_revenues_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_revenues_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_revenues_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_revenues`
--

LOCK TABLES `financial_revenues` WRITE;
/*!40000 ALTER TABLE `financial_revenues` DISABLE KEYS */;
INSERT INTO `financial_revenues` VALUES (1,1,1,'Invoice #001 - Web Development',5000.00,'RON','2025-08-12',NULL,2025,8,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(2,1,1,'Invoice #002 - SEO Services',1200.00,'EUR','2025-08-25',NULL,2025,8,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(3,1,1,'Invoice #003 - Mobile App',8500.00,'RON','2025-09-03',NULL,2025,9,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(4,1,1,'Invoice #004 - Consulting',2000.00,'EUR','2025-09-04',NULL,2025,9,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(5,1,1,'Invoice #005 - Website Redesign',6200.00,'RON','2025-10-18',NULL,2025,10,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(6,1,1,'Invoice #006 - Maintenance',800.00,'EUR','2025-10-16',NULL,2025,10,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(7,1,1,'Invoice #007 - E-commerce Platform',12000.00,'RON','2025-11-14',NULL,2025,11,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(8,1,1,'Invoice #008 - API Integration',3500.00,'EUR','2025-11-12',NULL,2025,11,'Sample revenue entry for testing','2025-11-10 18:38:53','2025-11-10 18:38:53',NULL);
/*!40000 ALTER TABLE `financial_revenues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_settings`
--

DROP TABLE IF EXISTS `financial_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `option_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'expense_category',
  `option_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'slate',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `financial_settings_organization_id_option_type_index` (`organization_id`,`option_type`),
  KEY `financial_settings_sort_order_index` (`sort_order`),
  CONSTRAINT `financial_settings_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_settings`
--

LOCK TABLES `financial_settings` WRITE;
/*!40000 ALTER TABLE `financial_settings` DISABLE KEYS */;
INSERT INTO `financial_settings` VALUES (1,1,'expense_category','Marketing & Advertising','marketing','blue',1,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(2,1,'expense_category','Software & Tools','software','purple',2,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(3,1,'expense_category','Hosting & Infrastructure','hosting','green',3,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(4,1,'expense_category','Office & Supplies','office','yellow',4,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(5,1,'expense_category','Professional Services','services','orange',5,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(6,1,'expense_category','Salaries & Payroll','salaries','red',6,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(7,1,'expense_category','Utilities','utilities','slate',7,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL),(8,1,'expense_category','Other','other','pink',8,'2025-11-10 18:38:53','2025-11-10 18:38:53',NULL);
/*!40000 ALTER TABLE `financial_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `internal_accounts`
--

DROP TABLE IF EXISTS `internal_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `nume_cont_aplicatie` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `platforma` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `accesibil_echipei` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `internal_accounts_user_id_foreign` (`user_id`),
  KEY `internal_accounts_organization_id_user_id_index` (`organization_id`,`user_id`),
  KEY `internal_accounts_organization_id_accesibil_echipei_index` (`organization_id`,`accesibil_echipei`),
  KEY `internal_accounts_platform_index` (`platforma`),
  CONSTRAINT `internal_accounts_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `internal_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `internal_accounts`
--

LOCK TABLES `internal_accounts` WRITE;
/*!40000 ALTER TABLE `internal_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `internal_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_11_09_175217_create_organizations_table',1),(5,'2025_11_09_175258_add_role_and_org_to_users_table',1),(6,'2025_11_09_175258_create_client_settings_table',1),(7,'2025_11_09_175259_create_clients_table',1),(8,'2025_11_09_175259_create_contracts_table',1),(9,'2025_11_09_175259_create_offers_table',1),(10,'2025_11_09_175300_create_annexes_table',1),(11,'2025_11_09_175301_create_access_credentials_table',1),(12,'2025_11_09_175301_create_expenses_table',1),(13,'2025_11_09_175301_create_files_table',1),(14,'2025_11_09_175302_create_audit_logs_table',1),(15,'2025_11_09_175302_create_revenues_table',1),(16,'2025_11_09_175303_create_system_settings_table',1),(17,'2025_11_09_195752_create_subscriptions_table',1),(18,'2025_11_09_195815_create_subscription_logs_table',1),(19,'2025_11_09_202300_create_internal_accounts_table',1),(20,'2025_11_09_213600_create_domains_table',1),(21,'2025_11_10_061850_remove_organization_id_from_subscriptions_table',1),(22,'2025_11_10_132712_create_settings_tables',1),(23,'2025_11_10_183057_create_financial_settings_table',1),(24,'2025_11_10_183058_create_financial_revenues_table',1),(25,'2025_11_10_183059_create_financial_expenses_table',1),(26,'2025_11_10_183059_create_financial_files_table',1),(27,'2025_11_10_190443_add_year_month_type_to_financial_files_table',2),(28,'2025_11_11_084336_create_application_settings_table',3),(29,'2025_11_11_120000_add_performance_indexes',4),(30,'2025_11_11_124059_add_additional_columns_to_clients_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `offer_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `valid_until` date DEFAULT NULL,
  `status` enum('draft','sent','approved','rejected','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `sent_date` date DEFAULT NULL,
  `approved_date` date DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offers_offer_number_unique` (`offer_number`),
  KEY `offers_client_id_foreign` (`client_id`),
  KEY `offers_organization_id_client_id_status_index` (`organization_id`,`client_id`,`status`),
  CONSTRAINT `offers_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `offers_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers`
--

LOCK TABLES `offers` WRITE;
/*!40000 ALTER TABLE `offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `tax_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `status` enum('active','inactive','suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organizations_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,'Demo Company Inc','demo-company',NULL,'info@democompany.com','+1-555-123-4567','123 Business Street','TAX-123456','billing@democompany.com',NULL,'active','2025-11-10 18:38:09','2025-11-10 18:38:09',NULL);
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revenues`
--

DROP TABLE IF EXISTS `revenues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revenues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `revenue_date` date NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revenues_client_id_foreign` (`client_id`),
  KEY `revenues_recorded_by_foreign` (`recorded_by`),
  KEY `revenues_organization_id_client_id_revenue_date_index` (`organization_id`,`client_id`,`revenue_date`),
  CONSTRAINT `revenues_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `revenues_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `revenues_recorded_by_foreign` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revenues`
--

LOCK TABLES `revenues` WRITE;
/*!40000 ALTER TABLE `revenues` DISABLE KEYS */;
/*!40000 ALTER TABLE `revenues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1hgLUESOTpYK8cfAdy0KfEeuVexZcXQRK1tZRJVQ',1,'193.231.148.210','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNzJOSVVmOUJ5OW9GYTdzQ2M3VDJtRHJsMEYxZGc4dElocUhWbFhpViI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vc2FkLnNpbXBsZWFkLnJvL2NsaWVudHM/dmlldz10YWJsZSI7czo1OiJyb3V0ZSI7czoxMzoiY2xpZW50cy5pbmRleCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==',1762864952),('96w1if07WlXQfxM11UsX8tbb3dybOqn4DdzRQLU1',NULL,'91.84.86.2','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOXFndEduWGIydXFST05xQkI4R1Bvb3BWeFppM0VWU3JSVUhhR3ZxVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vc2FkLnNpbXBsZWFkLnJvIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1762860577),('L2hjNBDORrSaIqwUyFTxV0LNuCD9zTY7nFNd6QnC',1,'109.166.128.255','Mozilla/5.0 (iPhone; CPU iPhone OS 26_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Brave/1 Mobile/15E148 Safari/604.1','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQlBDajBIN2p3RHN0R21TZ2wzY0YzdklNNW5KQmR2T0NzM1B4cE1uaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vc2FkLnNpbXBsZWFkLnJvL2Rhc2hib2FyZCI7czo1OiJyb3V0ZSI7czo5OiJkYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=',1762860846),('pWYTpHy0KhhaUFxQFad0fEtTSVi4oQtzutmhmSRK',NULL,'206.189.128.93','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDg4Nms0b3hZN2t2dlY2RzBrclluOUs3emtpYjhvVUFzT1BUWVlXeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vc2FkLnNpbXBsZWFkLnJvIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1762863331);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting_categories`
--

DROP TABLE IF EXISTS `setting_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting_categories`
--

LOCK TABLES `setting_categories` WRITE;
/*!40000 ALTER TABLE `setting_categories` DISABLE KEYS */;
INSERT INTO `setting_categories` VALUES (1,'Domains','domains','globe','Domain management settings',1,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(2,'Access','access','key','Credentials and access management settings',2,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(3,'Clients','clients','users','Client management settings',3,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(4,'Financial','financial','dollar-sign','Financial and accounting settings',4,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(5,'Subscriptions','subscriptions','repeat','Subscription management settings',5,1,'2025-11-11 06:10:06','2025-11-11 06:10:06');
/*!40000 ALTER TABLE `setting_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting_groups`
--

DROP TABLE IF EXISTS `setting_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `has_colors` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_groups_slug_unique` (`slug`),
  UNIQUE KEY `setting_groups_key_unique` (`key`),
  KEY `setting_groups_category_id_foreign` (`category_id`),
  CONSTRAINT `setting_groups_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `setting_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting_groups`
--

LOCK TABLES `setting_groups` WRITE;
/*!40000 ALTER TABLE `setting_groups` DISABLE KEYS */;
INSERT INTO `setting_groups` VALUES (1,1,'Registrars','domain-registrars','domain_registrars','Domain name registrars',1,0,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(2,1,'Statuses','domain-statuses','domain_statuses','Domain status options',2,1,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(3,2,'Platforms','access-platforms','access_platforms','Platform/service types',1,0,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(4,3,'Statuses','client-statuses','client_statuses','Client status options',1,1,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(5,4,'Expense Categories','expense-categories','expense_categories','Categories for expenses',1,0,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(6,4,'Payment Methods','payment-methods','payment_methods','Available payment methods',2,0,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(7,5,'Statuses','subscription-statuses','subscription_statuses','Subscription status options',1,1,1,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(8,5,'Billing Cycles','billing-cycles','billing_cycles','Subscription billing cycle options',2,0,1,'2025-11-11 06:10:06','2025-11-11 06:10:06');
/*!40000 ALTER TABLE `setting_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting_options`
--

DROP TABLE IF EXISTS `setting_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) unsigned NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_options_group_id_value_unique` (`group_id`,`value`),
  CONSTRAINT `setting_options_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `setting_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting_options`
--

LOCK TABLES `setting_options` WRITE;
/*!40000 ALTER TABLE `setting_options` DISABLE KEYS */;
INSERT INTO `setting_options` VALUES (1,1,'GoDaddy','godaddy',NULL,NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:48:54'),(3,1,'Google Domains','google-domains',NULL,NULL,1,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:48:54'),(4,1,'Cloudflare','cloudflare',NULL,NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:48:54'),(5,1,'Name.com','name-com',NULL,NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:48:54'),(6,1,'Hover','hover',NULL,NULL,5,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:48:54'),(7,1,'Other','other',NULL,NULL,6,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:48:54'),(8,2,'Active','active','#10b981',NULL,1,1,1,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(9,2,'Pending','pending','#f59e0b',NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(10,2,'Expired','expired','#ef4444',NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(11,2,'Suspended','suspended','#8b5cf6',NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(12,2,'Cancelled','cancelled','#6b7280',NULL,5,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(13,3,'cPanel','cpanel',NULL,NULL,1,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(14,3,'FTP','ftp',NULL,NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(15,3,'SSH','ssh',NULL,NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(16,3,'Database','database',NULL,NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(17,3,'Admin Panel','admin-panel',NULL,NULL,5,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(18,3,'Email','email',NULL,NULL,6,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(19,3,'Cloud Service','cloud-service',NULL,NULL,7,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(20,3,'API','api',NULL,NULL,8,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(21,3,'Other','other',NULL,NULL,99,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(22,4,'Active','active','#10b981',NULL,1,1,1,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(23,4,'Inactive','inactive','#6b7280',NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(24,4,'Prospect','prospect','#3b82f6',NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(25,4,'Suspended','suspended','#f59e0b',NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(26,5,'Software Licenses','software-licenses',NULL,NULL,1,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(27,5,'Hosting & Servers','hosting-servers',NULL,NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(28,5,'Domain Registrations','domain-registrations',NULL,NULL,0,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(29,5,'Marketing & Advertising','marketing-advertising',NULL,NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(30,5,'Professional Services','professional-services',NULL,NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(31,5,'Office Supplies','office-supplies',NULL,NULL,5,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(32,5,'Other','other',NULL,NULL,6,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 08:55:29'),(33,6,'Credit Card','credit-card',NULL,NULL,1,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(34,6,'Bank Transfer','bank-transfer',NULL,NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(35,6,'PayPal','paypal',NULL,NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(36,6,'Stripe','stripe',NULL,NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(37,6,'Cash','cash',NULL,NULL,5,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(38,6,'Check','check',NULL,NULL,6,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(39,6,'Other','other',NULL,NULL,99,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(40,7,'Active','active','#10b981',NULL,1,1,1,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(41,7,'Cancelled','cancelled','#6b7280',NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(42,7,'Expired','expired','#ef4444',NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(43,7,'Pending','pending','#f59e0b',NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(44,8,'Monthly','monthly',NULL,NULL,1,1,1,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(45,8,'Quarterly','quarterly',NULL,NULL,2,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(46,8,'Semi-Annual','semi-annual',NULL,NULL,3,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(47,8,'Annual','annual',NULL,NULL,4,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(48,8,'Biennial','biennial',NULL,NULL,5,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06'),(49,8,'One-Time','one-time',NULL,NULL,6,1,0,NULL,'2025-11-11 06:10:06','2025-11-11 06:10:06');
/*!40000 ALTER TABLE `setting_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_logs`
--

DROP TABLE IF EXISTS `subscription_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint(20) unsigned NOT NULL,
  `organization_id` bigint(20) unsigned NOT NULL,
  `old_renewal_date` date NOT NULL,
  `new_renewal_date` date NOT NULL,
  `change_reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_by_user_id` bigint(20) unsigned DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `subscription_logs_changed_by_user_id_foreign` (`changed_by_user_id`),
  KEY `subscription_logs_subscription_id_index` (`subscription_id`),
  KEY `subscription_logs_organization_id_subscription_id_index` (`organization_id`,`subscription_id`),
  CONSTRAINT `subscription_logs_changed_by_user_id_foreign` FOREIGN KEY (`changed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `subscription_logs_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_logs`
--

LOCK TABLES `subscription_logs` WRITE;
/*!40000 ALTER TABLE `subscription_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `vendor_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `billing_cycle` enum('monthly','annual','custom') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `custom_days` int(11) DEFAULT NULL,
  `start_date` date NOT NULL,
  `next_renewal_date` date NOT NULL,
  `status` enum('active','paused','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_next_renewal_date_index` (`next_renewal_date`),
  KEY `subscriptions_user_id_index` (`user_id`),
  KEY `subscriptions_status_index` (`status`),
  KEY `subscriptions_user_id_status_compound_index` (`user_id`,`status`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_settings_key_unique` (`key`),
  KEY `system_settings_organization_id_key_index` (`organization_id`,`key`),
  CONSTRAINT `system_settings_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `role` enum('admin','manager','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_organization_id_foreign` (`organization_id`),
  CONSTRAINT `users_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Andrei Alexandru Panait','andrei.panait@simplead.ro',NULL,'$2y$12$e.tuN4NqnyGWnGqTCDfkP.ANu/o7hGehGbmH02eh6jV94lE3Hs2u2','spGqoGMrtzGmK5XxRavgSuwf6k6Oexd5jYeaLhpWK6qFOoNxwpFiy0uW6Y2P','2025-11-10 18:38:09','2025-11-11 05:44:25',1,'admin','+1-555-999-0001','active'),(2,'Manager User','manager@example.com',NULL,'$2y$12$AM1tC5hn4jFBToGZJzyoIOkBMWOaFaLkzufm6v.WF.IU0oOoUTjKm',NULL,'2025-11-10 18:38:09','2025-11-10 18:38:09',1,'manager','+1-555-999-0002','active');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'laravel_erp'
--

--
-- Dumping routines for database 'laravel_erp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-11 12:42:37
